length = int(input("What is the length of the rectangle? (cm) "))
width = int(input("What is the width of the rectangle? (cm) "))
area = length * width
guess = int(input("What is the area of the rectangle? (cm2) "))
if guess == area :
  print("You got it right!")
else :
  print("Try again.")